const SUPABASE_URL='https://znzgumiwgmidfctdpxkq.supabase.co';
const SUPABASE_KEY='sb_publishable_PVSqrL2kXWFLxuXUGDl-FQ_gX55Cn16';
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let currentCase=null, currentUser=null;
const $=id=>document.getElementById(id);
function show(id){document.querySelectorAll('main section').forEach(s=>s.classList.add('hidden'));$(id).classList.remove('hidden')}
async function boot(){const {data:{session}}=await sb.auth.getSession(); if(!session){show('login');return;} currentUser=session.user; $('who').textContent=currentUser.email; show('dashboard'); await loadCases();}
async function signIn(e){e.preventDefault();$('loginMsg').textContent='Signing in…';const {error}=await sb.auth.signInWithPassword({email:$('email').value,password:$('password').value}); if(error){$('loginMsg').textContent=error.message;return;} await boot();}
async function logout(){await sb.auth.signOut();location.reload()}
async function loadCases(){const {data,error}=await sb.from('case_workspace').select('*').order('updated_at',{ascending:false});if(error){$('queue').innerHTML=`<tr><td colspan=4>${error.message}</td></tr>`;return;}const rows=data||[];$('mActive').textContent=rows.length;$('mQR').textContent=rows.filter(x=>x.status==='ready_for_quality_review').length;$('mWait').textContent=rows.filter(x=>['waiting_on_taxpayer','waiting_on_documents'].includes(x.status)).length;$('mTransmit').textContent=rows.filter(x=>x.status==='ready_to_transmit').length;const html=rows.map(x=>`<tr onclick="openCase('${x.case_id}')"><td><b>${esc(x.first_name)} ${esc(x.last_name)}</b></td><td>${x.tax_year}</td><td><span class=status>${pretty(x.status)}</span></td><td>${esc(x.next_action||'Open case')}</td></tr>`).join('')||'<tr><td colspan=4>No cases available for this account.</td></tr>';$('queue').innerHTML=html;$('clientRows').innerHTML=html.replaceAll('colspan=4','colspan=5');}
async function openCase(id){currentCase=id;show('case');const {data}=await sb.from('case_workspace').select('*').eq('case_id',id).single();$('caseName').textContent=`${data.first_name} ${data.last_name}`;$('caseMeta').textContent=`Tax Year ${data.tax_year} · ${pretty(data.status)}`;$('caseStatus').textContent=pretty(data.status);$('nextAction').textContent=data.next_action||'Review current controls.';await Promise.all([loadForms(),loadDD(),loadNotes()]);}
async function loadForms(){const {data}=await sb.from('case_form_queue').select('*').eq('case_id',currentCase).order('code');$('forms').innerHTML=(data||[]).map(f=>`<div class=row><b>${esc(f.code)}</b><span>${esc(f.full_name)} <small>— ${pretty(f.status)}</small></span></div>`).join('')||'No routed forms.'}
async function loadDD(){const {data}=await sb.from('due_diligence_answers').select('id,credit_type,question_label,draft_answer,preparer_answer,evidence_status').eq('case_id',currentCase).order('credit_type');$('ddAnswers').innerHTML=(data||[]).map(a=>`<div class="dditem"><div><b>${esc(a.credit_type)} — ${esc(a.question_label)}</b><span class="status ${a.evidence_status==='supported'?'green':'amber'}">${pretty(a.evidence_status)}</span></div><textarea id="ans-${a.id}" placeholder="Preparer response">${esc(a.preparer_answer||a.draft_answer||'')}</textarea><div class=ddactions><button class=secondary onclick="saveAnswer('${a.id}')">Save</button><button class=action onclick="copyAnswer('${a.id}')">Copy Answer</button></div></div>`).join('')||'<div class=muted>No due-diligence questions have been generated for this case yet.</div>'}
async function saveAnswer(id){const val=$(`ans-${id}`).value;const {error}=await sb.from('due_diligence_answers').update({preparer_answer:val,reviewed_by:currentUser.id,reviewed_at:new Date().toISOString()}).eq('id',id);toast(error?error.message:'Answer saved.');}
async function copyAnswer(id){const {data,error}=await sb.rpc('copy_ready_due_diligence',{p_answer:id});if(error)return toast(error.message);await navigator.clipboard.writeText(data||'PREPARER RESPONSE REQUIRED');toast(data==='PREPARER RESPONSE REQUIRED'?'Preparer review required before use.':'Copy-ready answer copied.');}
async function loadNotes(){const {data}=await sb.from('preparer_case_notes').select('*').eq('case_id',currentCase).order('created_at',{ascending:false});$('noteHistory').innerHTML=(data||[]).map(n=>`<div class=audit><b>${n.note_type==='misc_private'?'Private Misc. Note':'Due Diligence Note'}</b><div>${esc(n.note_text)}</div></div>`).join('')||'<div class=muted>No internal notes yet.</div>'}
async function addNote(type){const box=type==='misc_private'?'miscNote':'ddNote',val=$(box).value.trim();if(!val)return;const {error}=await sb.from('preparer_case_notes').insert({case_id:currentCase,author_user_id:currentUser.id,note_type:type,note_text:val,is_private:true});if(error)return toast(error.message);$(box).value='';await loadNotes();toast('Private internal note saved.');}
function nav(id,btn){show(id);document.querySelectorAll('.side button').forEach(b=>b.classList.remove('active'));if(btn)btn.classList.add('active');if(id==='clients')loadCases()}
function pretty(v){return (v||'').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase())}function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}function toast(t){$('toast').textContent=t;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2400)}
document.addEventListener('DOMContentLoaded',boot);

let myFirms=[], routingTriggers=[];
async function loadPortalContext(){
  const [{data:firms,error:fe},{data:triggers,error:te}]=await Promise.all([
    sb.from('my_firm_roles').select('*').order('firm_name'),
    sb.from('routing_trigger_catalog').select('*').order('trigger_label')
  ]);
  myFirms=firms||[]; routingTriggers=triggers||[];
  const canCreate=myFirms.some(f=>f.role==='administrator' && f.active);
  const b=$('newCaseBtn'); if(b) b.classList.toggle('hidden',!canCreate);
  if(fe) toast(fe.message); if(te) console.warn(te.message);
}
async function openNewCase(){
  await loadPortalContext();
  const admins=myFirms.filter(f=>f.role==='administrator'&&f.active);
  if(!admins.length){toast('Administrator access is required to create a taxpayer case.');return;}
  $('caseFirm').innerHTML=admins.map(f=>`<option value="${esc(f.firm_id)}">${esc(f.firm_name)}</option>`).join('');
  $('newTaxYear').value=new Date().getFullYear()-1;
  $('triggerList').innerHTML=routingTriggers.map(t=>`<label class="check"><input type="checkbox" class="routeTrigger" value="${esc(t.trigger_key)}"><span><b>${esc(t.trigger_label||pretty(t.trigger_key))}</b><br><small>${t.routed_form_count} routed form${Number(t.routed_form_count)===1?'':'s'}</small></span></label>`).join('')||'<div class=muted>No specialty routing rules available.</div>';
  $('newCaseMsg').textContent=''; show('newcase');
}
async function createCase(e){
  e.preventDefault();
  const msg=$('newCaseMsg'); msg.textContent='Creating taxpayer and return…';
  const params={p_firm:$('caseFirm').value,p_first_name:$('newFirst').value.trim(),p_last_name:$('newLast').value.trim(),p_email:$('newEmail').value.trim()||null,p_phone:$('newPhone').value.trim()||null,p_tax_year:Number($('newTaxYear').value)};
  const {data,error}=await sb.rpc('create_tax_case',params);
  if(error){msg.textContent=error.message;return;}
  const caseId=typeof data==='string'?data:(data?.id||data?.case_id||data);
  if(!caseId){msg.textContent='Case was created, but the case identifier was not returned.';await loadCases();return;}
  const selected=[...document.querySelectorAll('.routeTrigger:checked')].map(x=>x.value);
  for(const key of selected){const {error:re}=await sb.rpc('set_case_trigger',{p_case:caseId,p_trigger_key:key,p_active:true});if(re){msg.textContent=`Case created. Routing warning: ${re.message}`;await loadCases();await openCase(caseId);return;}}
  msg.textContent='Case created and routed.'; await loadCases(); await openCase(caseId); toast('New taxpayer return created.');
}
const _boot=boot;
boot=async function(){await _boot();if(currentUser)await loadPortalContext();};
